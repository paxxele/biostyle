BIOSTYLE — SITIO WEB

Archivos:
- index.html: estructura y contenido del sitio.
- styles.css: diseño visual y adaptación a celulares.
- script.js: menú móvil, año automático y formulario de consulta.

Cómo abrir:
1. Descargá y descomprimí biostyle_web.zip.
2. Abrí index.html con Chrome, Edge o Firefox.

Antes de publicar:
- En script.js, reemplazá contacto@biostyle.com por el correo real.
- Actualizá los enlaces/redes sociales si querés agregarlos.
- El diseño del frasco y del QR son ilustraciones CSS decorativas, no fotos ni códigos QR funcionales.
- El formulario abre el correo del visitante mediante mailto; no guarda datos en un servidor.
- El contenido se basa en la propuesta del proyecto. No se incluyen precios ni afirmaciones de eficacia no confirmadas.
